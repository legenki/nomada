const R = { enabled: !1 }, f = {
  version: 3,
  enabled: !0,
  mode: "system",
  profiles: [],
  activeProfileId: void 0,
  lastProfileId: void 0,
  geo: R,
  syncEnabled: !0,
  syncDismissed: [],
  settings: { notifyChange: !0, notifyError: !0 }
};
function U(e) {
  return !e.version && (e.timezone !== void 0 || e.lat !== void 0);
}
function L(e) {
  return e.version === 2 && Array.isArray(e.profiles);
}
function O(e) {
  if (!e || typeof e != "object") return { ...f };
  const o = e;
  if (o.version === 3) {
    const t = Array.isArray(o.profiles) ? o.profiles : [], n = o.activeProfileId && t.some((r) => (r == null ? void 0 : r.id) === o.activeProfileId), a = o.mode, i = ["direct", "system", "profile"].includes(a) ? a === "profile" && !n ? "system" : a : "system";
    return {
      ...f,
      ...o,
      version: 3,
      enabled: o.enabled === void 0 ? !0 : !!o.enabled,
      mode: i,
      profiles: t,
      activeProfileId: i === "profile" ? o.activeProfileId : void 0,
      lastProfileId: o.lastProfileId ?? (i === "profile" ? o.activeProfileId : void 0)
    };
  }
  if (U(o)) {
    const t = {
      enabled: !!(o.timezone || o.lat),
      timezone: o.timezone,
      locale: o.locale,
      lat: o.lat,
      lon: o.lon,
      locationKey: o.configuration !== "browserDefault" && o.configuration !== "custom" ? o.configuration : void 0
    };
    return { ...f, geo: t };
  }
  if (L(o)) {
    const t = Array.isArray(o.profiles) ? o.profiles : [], a = o.activeProfileId && t.some((i) => (i == null ? void 0 : i.id) === o.activeProfileId) ? "profile" : "system";
    return {
      ...f,
      profiles: t,
      mode: a,
      activeProfileId: a === "profile" ? o.activeProfileId : void 0
    };
  }
  return { ...f };
}
const p = "wooportal-data";
async function l() {
  const e = await chrome.storage.local.get([p]);
  return O(e[p]);
}
async function u(e) {
  await chrome.storage.local.set({ [p]: { ...e, version: 3 } });
}
async function y(e) {
  const o = await l();
  await u({ ...o, geo: e });
}
async function _(e) {
  const o = await l(), t = [.../* @__PURE__ */ new Set([...o.syncDismissed, e])];
  await u({ ...o, syncDismissed: t });
}
const K = ["blue", "gray", "green", "orange", "purple", "red", "teal", "yellow"];
function G(e, o) {
  const t = [16, 32, 48, 128];
  let n;
  return e ? o && K.includes(o) ? n = `active-${o}` : n = "active-green" : n = "inactive", Object.fromEntries(t.map((a) => [`${a}`, `icons/icon-${n}-${a}.png`]));
}
const D = {
  blue: [9, 105, 218],
  gray: [128, 128, 128],
  green: [26, 127, 55],
  orange: [219, 109, 40],
  purple: [137, 87, 229],
  red: [207, 34, 46],
  teal: [23, 162, 184],
  yellow: [212, 153, 34]
};
function B(e) {
  const o = /^#?([0-9a-f]{6})$/i.exec(e.trim());
  if (!o) return null;
  const t = parseInt(o[1], 16);
  return [t >> 16 & 255, t >> 8 & 255, t & 255];
}
function x(e) {
  if (!e) return null;
  const o = B(e);
  if (!o) return null;
  let t = null, n = 1 / 0;
  for (const [a, i] of Object.entries(D)) {
    const r = (o[0] - i[0]) ** 2 + (o[1] - i[1]) ** 2 + (o[2] - i[2]) ** 2;
    r < n && (n = r, t = a);
  }
  return t;
}
const M = [
  { key: "auckland", name: "Auckland", country: "New Zealand", flag: "🇳🇿", timezone: "Pacific/Auckland", locale: "en-NZ", lat: -36.85, lon: 174.76, countryCode: "NZ" },
  { key: "sydney", name: "Sydney", country: "Australia", flag: "🇦🇺", timezone: "Australia/Sydney", locale: "en-AU", lat: -33.87, lon: 151.21, countryCode: "AU" },
  { key: "tokyo", name: "Tokyo", country: "Japan", flag: "🇯🇵", timezone: "Asia/Tokyo", locale: "ja-JP", lat: 35.69, lon: 139.69, countryCode: "JP" },
  { key: "seoul", name: "Seoul", country: "South Korea", flag: "🇰🇷", timezone: "Asia/Seoul", locale: "ko-KR", lat: 37.57, lon: 126.98, countryCode: "KR" },
  { key: "singapore", name: "Singapore", country: "Singapore", flag: "🇸🇬", timezone: "Asia/Singapore", locale: "en-SG", lat: 1.35, lon: 103.82, countryCode: "SG" },
  { key: "beijing", name: "Beijing", country: "China", flag: "🇨🇳", timezone: "Asia/Shanghai", locale: "zh-CN", lat: 39.9, lon: 116.41, countryCode: "CN" },
  { key: "shanghai", name: "Shanghai", country: "China", flag: "🇨🇳", timezone: "Asia/Shanghai", locale: "zh-CN", lat: 31.23, lon: 121.47, countryCode: "CN" },
  { key: "hongKong", name: "Hong Kong", country: "China", flag: "🇭🇰", timezone: "Asia/Hong_Kong", locale: "zh-HK", lat: 22.32, lon: 114.17, countryCode: "HK" },
  { key: "delhi", name: "Delhi", country: "India", flag: "🇮🇳", timezone: "Asia/Kolkata", locale: "hi-IN", lat: 28.61, lon: 77.1, countryCode: "IN" },
  { key: "mumbai", name: "Mumbai", country: "India", flag: "🇮🇳", timezone: "Asia/Kolkata", locale: "en-IN", lat: 19.08, lon: 72.88, countryCode: "IN" },
  { key: "dubai", name: "Dubai", country: "UAE", flag: "🇦🇪", timezone: "Asia/Dubai", locale: "ar-AE", lat: 25.2, lon: 55.27, countryCode: "AE" },
  { key: "tehran", name: "Tehran", country: "Iran", flag: "🇮🇷", timezone: "Asia/Tehran", locale: "fa-IR", lat: 35.69, lon: 51.39, countryCode: "IR" },
  { key: "saintPetersburg", name: "Saint Petersburg", country: "Russia", flag: "🇷🇺", timezone: "Europe/Moscow", locale: "ru-RU", lat: 59.93, lon: 30.32, countryCode: "RU" },
  { key: "moscow", name: "Moscow", country: "Russia", flag: "🇷🇺", timezone: "Europe/Moscow", locale: "ru-RU", lat: 55.76, lon: 37.62, countryCode: "RU" },
  { key: "istanbul", name: "Istanbul", country: "Turkey", flag: "🇹🇷", timezone: "Europe/Istanbul", locale: "tr-TR", lat: 41.01, lon: 28.98, countryCode: "TR" },
  { key: "kyiv", name: "Kyiv", country: "Ukraine", flag: "🇺🇦", timezone: "Europe/Kyiv", locale: "uk-UA", lat: 50.45, lon: 30.52, countryCode: "UA" },
  { key: "warsaw", name: "Warsaw", country: "Poland", flag: "🇵🇱", timezone: "Europe/Warsaw", locale: "pl-PL", lat: 52.23, lon: 21.01, countryCode: "PL" },
  { key: "berlin", name: "Berlin", country: "Germany", flag: "🇩🇪", timezone: "Europe/Berlin", locale: "de-DE", lat: 52.52, lon: 13.4, countryCode: "DE" },
  { key: "paris", name: "Paris", country: "France", flag: "🇫🇷", timezone: "Europe/Paris", locale: "fr-FR", lat: 48.86, lon: 2.35, countryCode: "FR" },
  { key: "london", name: "London", country: "UK", flag: "🇬🇧", timezone: "Europe/London", locale: "en-GB", lat: 51.51, lon: -0.13, countryCode: "GB" },
  { key: "amsterdam", name: "Amsterdam", country: "Netherlands", flag: "🇳🇱", timezone: "Europe/Amsterdam", locale: "nl-NL", lat: 52.37, lon: 4.9, countryCode: "NL" },
  { key: "madrid", name: "Madrid", country: "Spain", flag: "🇪🇸", timezone: "Europe/Madrid", locale: "es-ES", lat: 40.42, lon: -3.7, countryCode: "ES" },
  { key: "rome", name: "Rome", country: "Italy", flag: "🇮🇹", timezone: "Europe/Rome", locale: "it-IT", lat: 41.9, lon: 12.5, countryCode: "IT" },
  { key: "cairo", name: "Cairo", country: "Egypt", flag: "🇪🇬", timezone: "Africa/Cairo", locale: "ar-EG", lat: 30.04, lon: 31.24, countryCode: "EG" },
  { key: "lagos", name: "Lagos", country: "Nigeria", flag: "🇳🇬", timezone: "Africa/Lagos", locale: "en-NG", lat: 6.52, lon: 3.38, countryCode: "NG" },
  { key: "nairobi", name: "Nairobi", country: "Kenya", flag: "🇰🇪", timezone: "Africa/Nairobi", locale: "en-KE", lat: -1.29, lon: 36.82, countryCode: "KE" },
  { key: "newYork", name: "New York", country: "USA", flag: "🇺🇸", timezone: "America/New_York", locale: "en-US", lat: 40.71, lon: -74, countryCode: "US" },
  { key: "losAngeles", name: "Los Angeles", country: "USA", flag: "🇺🇸", timezone: "America/Los_Angeles", locale: "en-US", lat: 34.05, lon: -118.24, countryCode: "US" },
  { key: "chicago", name: "Chicago", country: "USA", flag: "🇺🇸", timezone: "America/Chicago", locale: "en-US", lat: 41.88, lon: -87.63, countryCode: "US" },
  { key: "toronto", name: "Toronto", country: "Canada", flag: "🇨🇦", timezone: "America/Toronto", locale: "en-CA", lat: 43.65, lon: -79.38, countryCode: "CA" },
  { key: "saoPaulo", name: "São Paulo", country: "Brazil", flag: "🇧🇷", timezone: "America/Sao_Paulo", locale: "pt-BR", lat: -23.55, lon: -46.63, countryCode: "BR" },
  { key: "mexicoCity", name: "Mexico City", country: "Mexico", flag: "🇲🇽", timezone: "America/Mexico_City", locale: "es-MX", lat: 19.43, lon: -99.13, countryCode: "MX" },
  { key: "bogota", name: "Bogotá", country: "Colombia", flag: "🇨🇴", timezone: "America/Bogota", locale: "es-CO", lat: 4.71, lon: -74.07, countryCode: "CO" },
  { key: "buenosAires", name: "Buenos Aires", country: "Argentina", flag: "🇦🇷", timezone: "America/Argentina/Buenos_Aires", locale: "es-AR", lat: -34.61, lon: -58.38, countryCode: "AR" }
];
function A(e) {
  return M.find((o) => o.key === e);
}
async function s() {
  var i, r;
  const e = await l(), o = e.enabled && e.geo.enabled, t = e.mode === "profile" && e.activeProfileId ? e.profiles.find((c) => c.id === e.activeProfileId) : void 0, n = o ? x(t == null ? void 0 : t.color) : null;
  chrome.action.setIcon({ path: G(o, n) }).catch(() => {
  });
  let a = "";
  if (o) {
    const c = e.geo.locationKey ? A(e.geo.locationKey) : null;
    a = (c == null ? void 0 : c.countryCode) ?? H(e.geo.cityName, e.geo.locale);
  }
  chrome.action.setBadgeText({ text: a }).catch(() => {
  }), chrome.action.setBadgeBackgroundColor({ color: "#1a7f37" }).catch(() => {
  }), (r = (i = chrome.action).setBadgeTextColor) == null || r.call(i, { color: "#ffffff" }).catch(() => {
  });
}
function H(e, o) {
  const t = o == null ? void 0 : o.split("-")[1];
  return t && t.length === 2 ? t.toUpperCase() : e ? e.slice(0, 2).toUpperCase() : "";
}
function F(e) {
  const { type: o, host: t, port: n } = e.config, { domains: a, mode: i } = e.config.routingRules, r = o === "socks5" ? `SOCKS5 ${t}:${n}` : `PROXY ${t}:${n}`, c = JSON.stringify(a);
  return (i ?? "whitelist") === "whitelist" ? `function FindProxyForURL(url,host){var w=${c};for(var i=0;i<w.length;i++){if(shExpMatch(host,w[i]))return "${r}";}return "DIRECT";}` : `function FindProxyForURL(url,host){var b=${c};for(var i=0;i<b.length;i++){if(shExpMatch(host,b[i]))return "DIRECT";}return "${r}";}`;
}
function $(e) {
  const o = e.trim();
  return o ? /^https?:\/\//i.test(o) || /^file:\/\//i.test(o) ? { url: o } : /^[a-zA-Z]:[\\\/]/.test(o) ? { url: "file:///" + o.replace(/\\/g, "/") } : o.startsWith("/") ? { url: "file://" + o } : null : null;
}
async function P(e) {
  try {
    const o = await l(), t = o.profiles.find((r) => r.id === e);
    if (!t) throw new Error("Profile not found");
    await chrome.proxy.settings.clear({ scope: "regular" }), await new Promise((r) => setTimeout(r, 100));
    const n = t.config.type;
    let a;
    if (n === "pac") {
      const r = $(t.config.pacUrl);
      if (!r) throw new Error("Invalid PAC URL");
      a = { mode: "pac_script", pacScript: { url: r.url } };
    } else {
      const { host: r, port: c, routingRules: g } = t.config;
      if (!r || !c) throw new Error("Missing host or port");
      g != null && g.enabled && g.domains.length > 0 ? a = { mode: "pac_script", pacScript: { data: F(t) } } : a = { mode: "fixed_servers", rules: { singleProxy: { scheme: n, host: r, port: c } } };
    }
    await chrome.proxy.settings.set({ value: a, scope: "regular" }), console.log("[wooPortal] proxy activated:", JSON.stringify(a));
    const i = { ...o, mode: "profile", activeProfileId: e };
    return await u(i), await s(), { success: !0 };
  } catch (o) {
    return console.error("[wooPortal] activateProxy failed:", o), { success: !1, error: o.message };
  }
}
async function b() {
  try {
    await chrome.proxy.settings.clear({ scope: "regular" }), await chrome.proxy.settings.set({ value: { mode: "system" }, scope: "regular" });
    const e = await l();
    return await u({ ...e, mode: "system", activeProfileId: void 0 }), await s(), { success: !0 };
  } catch (e) {
    return { success: !1, error: e.message };
  }
}
function m() {
  var e;
  return (e = chrome.runtime.lastError) == null ? void 0 : e.message;
}
function Y(e) {
  return new Promise((o) => {
    chrome.debugger.getTargets((t) => {
      m(), o(t.some((n) => n.tabId === e && n.attached));
    });
  });
}
function E(e) {
  return new Promise((o) => {
    chrome.debugger.detach({ tabId: e }, () => {
      m(), o();
    });
  });
}
function V(e) {
  return new Promise((o) => {
    chrome.debugger.attach({ tabId: e }, "1.3", () => {
      const t = m();
      o(!t);
    });
  });
}
function w(e, o, t) {
  return new Promise((n) => {
    chrome.debugger.sendCommand({ tabId: e }, o, t, () => {
      const a = m();
      n(!a);
    });
  });
}
async function v(e, o) {
  !o.enabled || !o.timezone && !o.locale && o.lat === void 0 || (await Y(e) && await E(e), !await V(e)) || o.timezone && !await w(e, "Emulation.setTimezoneOverride", { timezoneId: o.timezone }) || o.lat !== void 0 && o.lon !== void 0 && !await w(e, "Emulation.setGeolocationOverride", {
    latitude: o.lat,
    longitude: o.lon,
    accuracy: 1
  }) || o.locale && await w(e, "Emulation.setLocaleOverride", { locale: o.locale });
}
async function C() {
  const e = await new Promise(
    (o) => chrome.debugger.getTargets((t) => {
      m(), o(t);
    })
  );
  for (const o of e)
    o.attached && o.tabId && (await w(o.tabId, "Emulation.clearGeolocationOverride", {}), await E(o.tabId));
}
const S = {
  AU: "sydney",
  NZ: "auckland",
  JP: "tokyo",
  KR: "seoul",
  SG: "singapore",
  CN: "beijing",
  HK: "hongKong",
  IN: "delhi",
  AE: "dubai",
  IR: "tehran",
  RU: "saintPetersburg",
  TR: "istanbul",
  UA: "kyiv",
  PL: "warsaw",
  DE: "berlin",
  FR: "paris",
  GB: "london",
  NL: "amsterdam",
  ES: "madrid",
  IT: "rome",
  EG: "cairo",
  NG: "lagos",
  KE: "nairobi",
  US: "newYork",
  CA: "toronto",
  BR: "saoPaulo",
  MX: "mexicoCity",
  CO: "bogota",
  AR: "buenosAires"
}, Z = {
  AU: "en-AU",
  NZ: "en-NZ",
  JP: "ja-JP",
  KR: "ko-KR",
  SG: "en-SG",
  CN: "zh-CN",
  HK: "zh-HK",
  IN: "en-IN",
  AE: "ar-AE",
  IR: "fa-IR",
  RU: "ru-RU",
  TR: "tr-TR",
  UA: "uk-UA",
  PL: "pl-PL",
  DE: "de-DE",
  FR: "fr-FR",
  GB: "en-GB",
  NL: "nl-NL",
  ES: "es-ES",
  IT: "it-IT",
  EG: "ar-EG",
  NG: "en-NG",
  KE: "en-KE",
  US: "en-US",
  CA: "en-CA",
  BR: "pt-BR",
  MX: "es-MX",
  CO: "es-CO",
  AR: "es-AR",
  CH: "de-CH",
  AT: "de-AT",
  BE: "nl-BE",
  SE: "sv-SE",
  NO: "nb-NO",
  DK: "da-DK",
  FI: "fi-FI",
  PT: "pt-PT",
  GR: "el-GR",
  CZ: "cs-CZ",
  RO: "ro-RO",
  HU: "hu-HU",
  IE: "en-IE",
  IL: "he-IL",
  SA: "ar-SA",
  TH: "th-TH",
  VN: "vi-VN",
  ID: "id-ID",
  MY: "ms-MY",
  PH: "en-PH",
  ZA: "en-ZA",
  CL: "es-CL",
  PE: "es-PE"
};
function j(e) {
  return Z[e.toUpperCase()] ?? "en-US";
}
const k = "https://ipwho.is/", J = 10 * 60 * 1e3;
function T(e) {
  var o;
  return e.success ? {
    ip: e.ip,
    country: e.country,
    countryCode: e.country_code,
    city: e.city,
    lat: e.latitude,
    lon: e.longitude,
    timezone: (o = e.timezone) == null ? void 0 : o.id
  } : null;
}
let d = null;
async function N() {
  if (d && Date.now() - d.fetchedAt < J)
    return d.data;
  try {
    const e = new AbortController(), o = setTimeout(() => e.abort(), 5e3), t = `${k}?_=${Date.now()}`, n = await fetch(t, { signal: e.signal, cache: "no-store" });
    clearTimeout(o);
    const a = T(await n.json());
    if (console.log("[wooPortal] ipwho (sw) resolved IP:", a == null ? void 0 : a.ip, "| country:", a == null ? void 0 : a.countryCode, "| city:", a == null ? void 0 : a.city), a)
      return d = { data: a, fetchedAt: Date.now() }, a;
  } catch (e) {
    console.error("[wooPortal] ipwho fetch failed:", e);
  }
  return null;
}
async function X() {
  let e;
  try {
    [e] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
  } catch {
    return null;
  }
  if (!(e != null && e.id) || !e.url || /^(chrome|edge|about|chrome-extension):/i.test(e.url))
    return null;
  try {
    const [o] = await chrome.scripting.executeScript({
      target: { tabId: e.id },
      world: "MAIN",
      func: async (n) => {
        try {
          return await (await fetch(n, { cache: "no-store" })).json();
        } catch {
          return null;
        }
      },
      args: [`${k}?_=${Date.now()}`]
    }), t = o != null && o.result ? T(o.result) : null;
    if (t)
      return console.log("[wooPortal] ipwho (via tab) resolved IP:", t.ip, "| country:", t.countryCode, "| city:", t.city), d = { data: t, fetchedAt: Date.now() }, t;
  } catch (o) {
    console.error("[wooPortal] ipwho via tab failed:", o);
  }
  return null;
}
function q(e, o, t) {
  if (!o || !S[e.toUpperCase()]) return !1;
  const a = A(o);
  return !((a == null ? void 0 : a.countryCode.toUpperCase()) === e.toUpperCase() || t.map((r) => r.split(":")[1]).filter(Boolean).includes(e.toUpperCase()));
}
function W(e) {
  const o = S[e.toUpperCase()];
  if (!o) return null;
  const t = A(o);
  return t ? {
    countryCode: e.toUpperCase(),
    locationKey: t.key,
    city: t.name,
    timezone: t.timezone,
    locale: t.locale,
    lat: t.lat,
    lon: t.lon
  } : null;
}
async function Q() {
  const e = await N();
  return (e == null ? void 0 : e.countryCode) ?? null;
}
async function ee() {
  const e = await X() ?? await N();
  return !e || e.lat === void 0 || e.lon === void 0 ? null : {
    city: e.city || e.country || "Unknown",
    country: e.country || "",
    countryCode: e.countryCode || "",
    lat: e.lat,
    lon: e.lon,
    timezone: e.timezone || "UTC",
    locale: j(e.countryCode || "")
  };
}
function z() {
  d = null;
}
let h = null;
function oe() {
  h && clearTimeout(h), h = setTimeout(() => {
    h = null;
  }, 25e3);
}
async function te() {
  const e = await l(), o = e.mode === "profile" && e.activeProfileId ? e.profiles.find((t) => t.id === e.activeProfileId) ?? null : null;
  return {
    enabled: e.enabled,
    mode: e.mode,
    profiles: e.profiles,
    activeProfile: o,
    geo: e.geo,
    suggestion: null
  };
}
async function ae() {
  z();
  const e = await ee();
  if (!e) return { success: !1, error: "Could not determine IP location" };
  await y({
    enabled: !0,
    timezone: e.timezone,
    locale: e.locale,
    lat: e.lat,
    lon: e.lon,
    locationKey: void 0,
    cityName: e.city
  });
  const o = await l();
  return await u({ ...o, enabled: !0 }), await I(), await s(), { success: !0, cityName: e.city };
}
async function ne() {
  const e = await l();
  await y({ ...e.geo, enabled: !0 }), await I();
  const o = e.activeProfileId ?? e.lastProfileId, t = o && e.profiles.some((i) => i.id === o);
  let n = { success: !0 };
  t && (n = await P(o));
  const a = await l();
  return await u({ ...a, enabled: !0 }), await s(), n;
}
async function re() {
  const e = await l();
  await C(), await b();
  const o = await l();
  return await u({
    ...o,
    enabled: !1,
    geo: { ...o.geo, enabled: !1 },
    lastProfileId: e.activeProfileId ?? e.lastProfileId
  }), await s(), { success: !0 };
}
async function I() {
  const e = await l();
  if (!e.geo.enabled) return;
  const [o] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
  o != null && o.id && (await C(), await v(o.id, e.geo));
}
async function ie() {
  const e = await l(), o = e.mode === "profile" && e.activeProfileId ? e.profiles.find((n) => n.id === e.activeProfileId) ?? null : null;
  if (!(e.mode === "profile" && o && e.syncEnabled)) return null;
  const t = await Q();
  return t && q(t, e.geo.locationKey, e.syncDismissed) ? W(t) : null;
}
chrome.proxy.onProxyError.addListener((e) => {
  console.error("[wooPortal] PROXY ERROR:", e.error, "| fatal:", e.fatal, "| details:", e.details);
});
chrome.storage.onChanged.addListener((e, o) => {
  o === "local" && s();
});
s();
chrome.runtime.onInstalled.addListener(() => {
  s();
});
chrome.runtime.onStartup.addListener(() => {
  s();
});
chrome.webNavigation.onBeforeNavigate.addListener(async (e) => {
  if (e.frameId !== 0) return;
  const o = await l();
  o.geo.enabled && ((await new Promise(
    (a) => chrome.debugger.getTargets(a)
  )).find((a) => a.tabId === e.tabId && a.attached) || await v(e.tabId, o.geo));
});
chrome.webRequest.onAuthRequired.addListener(
  (e, o) => {
    if (!e.isProxy) {
      o({});
      return;
    }
    l().then((t) => {
      if (t.mode === "profile" && t.activeProfileId) {
        const n = t.profiles.find((i) => i.id === t.activeProfileId), a = n == null ? void 0 : n.config.auth;
        if (a != null && a.username) {
          o({ authCredentials: { username: a.username, password: a.password } });
          return;
        }
      }
      o({});
    });
  },
  { urls: ["<all_urls>"] },
  ["asyncBlocking"]
);
chrome.runtime.onMessage.addListener((e, o, t) => (oe(), (async () => {
  try {
    switch (e.type) {
      case "GET_STATE":
        t(await te());
        break;
      case "CHECK_SYNC":
        t({ suggestion: await ie() });
        break;
      case "SYNC_TO_IP":
        t(await ae());
        break;
      case "ACTIVATE_PROFILE": {
        z();
        const n = await P(e.payload.id);
        t(n);
        break;
      }
      case "DEACTIVATE_PROFILE":
        t(await b());
        break;
      case "ENABLE_ALL":
        t(await ne());
        break;
      case "DISABLE_ALL":
        t(await re());
        break;
      case "SET_GEO": {
        await y(e.payload), await I(), t({ success: !0 });
        break;
      }
      case "CLEAR_GEO": {
        await C(), await y({ enabled: !1 }), t({ success: !0 });
        break;
      }
      case "DISMISS_SYNC_SUGGESTION":
        await _(e.payload.pair), t({ success: !0 });
        break;
      case "ACCEPT_SYNC_SUGGESTION": {
        const n = {
          enabled: !0,
          timezone: e.payload.timezone,
          locale: e.payload.locale,
          lat: e.payload.lat,
          lon: e.payload.lon,
          locationKey: e.payload.locationKey
        };
        await C(), await y(n), t({ success: !0 });
        break;
      }
      default:
        t({ success: !0 });
    }
  } catch (n) {
    console.error("[wooPortal] message handler error:", n), t({ success: !1, error: n.message });
  }
})(), !0));
